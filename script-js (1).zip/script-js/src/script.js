/*  General Styless */

body {

    margin:  0;

    font-family: Arial, sans-serif;

  Scroll-behavior: smooth;

}

  header {

       background: 🔳#333;

        Color: ◽white;

       padding: 10px 20px;

}

. navbar {

     display: flex;

     justify-content: space-between;

 align-items: center;

}

. nav-links {

    list-style: none;

     display: flex;

}

. nav-links li {

    margin: 0 10px;

}

. nav-links a {

 color: ◽white;

 text-decoration: none;

}

.menu-toggle {

  display:none;

   font-size: 24px;

   cursor: pointer;

}

/* Hero section */

. hero {

     background: linear-gradient(to right,◽#4facfe, ◾#00f2fe);

  Color: ◽white;

  text-align: center;

  Padding: 60px 20px;

}

. hero h1 span{

      Color: 🟨yellow;

 }

. btn {

     backgroud: ◽white;

     Color: 🔳#333;

     padding: 10px 20px;

     text-decoration: none;

      margin-top: 20px;

     display: inline-block;

     border-radius: 5px;

}

/* About Section */

. about {

    padding: 40px 20px

    text-align: center;

}

. about-content {

     display: flex;

     flex-wrap:wrap;

     justify-content: center;

     align-items: center;

}

. about-content img {

     max-width: 150px;

     border-radius: 50%;

     margin: 20px;

}

/* Projects Section */

. projects {

   padding:40px 20px

  backgroud; ◽#f4f4f4;

  text-align: center;

}

. project-grid {

    display: grid;

     grid-template-colums: repeat(auto-fit, minmax(250px, 1fr));

gap: 20px;

}

. project-card {

     background:  ◽white;

      padding: 20px;

     border-radius: 10px;

     transition: transform 0.3s;

}

. project-card:hover {

     transform: scale(1.05);

}

/* contact section  */

. contact {

     padding: 40px 20px;

    text-align: center;

}

form{

    max-width: 400px;

    margin: auto;

}

input, textarea {

    width: 100%;

    padding: 10px; 

    margin: 10px 0;

}

button {

    backgroud: 🟦#4facfe;

    Color: ◽white;

    border: none;

    padding: 10px;

    width: 100%;

     cursor: pointer;

}

button. hover

     background: 🟦#00c6ff;

}

/* Footer */

footer {

  backgroud: 🔳#333;

   Color: ◽white;

    padding: 10px;

     text-align: center;

}

/* Responsive Navbar */

@media screen and(max-width: 768px) {

 . nav-links {

 display: none;

   flex-direction: column;

    backgroud: 🔳#333;

    position: absolute;

    top: 60px;

    right: 0;

    width: 200px;

}

. nav-links. show {

  display: flex;

}

. menu-toggl {

    display: block;

    }

}