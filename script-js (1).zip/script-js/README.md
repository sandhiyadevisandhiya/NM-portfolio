# Script.js

A Pen created on CodePen.

Original URL: [https://codepen.io/Narmatha-the-decoder/pen/NPxKaMN](https://codepen.io/Narmatha-the-decoder/pen/NPxKaMN).

